package Com.rental.customer;

import Com.rental.Transaction.rentalTransaction;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String name;
    private List<rentalTransaction> rentalHistory;

    public Customer(String name) {
        this.name = name;
        this.rentalHistory = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public List<rentalTransaction> getRentalHistory() {
        return rentalHistory;
    }

    // Add a rental transaction to the customer's rental history
    public void addRentalHistory(rentalTransaction transaction) {
        rentalHistory.add(transaction);
    }
}
