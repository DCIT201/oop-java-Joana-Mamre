package Com.rental.vehicle;

import Com.rental.Agency.RentalAgency;
import Com.rental.Transaction.rentalTransaction;
import Com.rental.customer.Customer;
import Com.rental.vehicle.vehicle.Car;
import Com.rental.vehicle.vehicle.Motorcycle;
import Com.rental.vehicle.vehicle.Truck;
import Com.rental.vehicle.vehicle.Vehicle;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create vehicles
        Vehicle car = new Car("C001", "Sedan", 50.0);
        Vehicle motorcycle = new Motorcycle("M001", "Harley", 30.0);
        Vehicle truck = new Truck("T001", "Ford", 100.0);

        // Create rental agency and add vehicles
        RentalAgency agency = new RentalAgency();
        agency.addVehicle(car);
        agency.addVehicle(motorcycle);
        agency.addVehicle(truck);

        // Create a customer
        Customer customer = new Customer("John Doe");

        // Display available vehicles
        System.out.println("Available vehicles for rent:");
        List<Vehicle> availableVehicles = agency.getAvailableVehicles();
        for (Vehicle vehicle : availableVehicles) {
            System.out.println(vehicle);
        }

        // Process rental transaction
        rentalTransaction transaction = new rentalTransaction(customer, car, 3);
        transaction.processTransaction();

        // Display available vehicles after rental
        System.out.println("\nAvailable vehicles after rental:");
        availableVehicles = agency.getAvailableVehicles();
        for (Vehicle vehicle : availableVehicles) {
            System.out.println(vehicle);
        }

        // Return vehicle
        transaction.returnVehicle();

        // Display available vehicles after return
        System.out.println("\nAvailable vehicles after return:");
        availableVehicles = agency.getAvailableVehicles();
        for (Vehicle vehicle : availableVehicles) {
            System.out.println(vehicle);
        }
    }
}
