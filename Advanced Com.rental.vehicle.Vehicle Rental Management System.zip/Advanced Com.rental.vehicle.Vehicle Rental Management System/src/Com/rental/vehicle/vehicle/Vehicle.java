package Com.rental.vehicle.vehicle;

import Com.rental.customer.Customer;
import Com.rental.vehicle.Rentable;

public abstract class Vehicle implements Rentable {
    private String vehicleId;
    private String model;
    private double baseRentalRate;
    private boolean isAvailable;

    public Vehicle(String vehicleId, String model, double baseRentalRate) {
        this.vehicleId = vehicleId;
        this.model = model;
        this.baseRentalRate = baseRentalRate;
        this.isAvailable = true; // By default, the vehicle is available
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public String getModel() {
        return model;
    }

    public double getBaseRentalRate() {
        return baseRentalRate;
    }

    public boolean isAvailableForRental() {
        return isAvailable;
    }

    // Abstract methods that will be implemented by subclasses
    public abstract double calculateRentalCost(int days);

    // Rent method from Rentable interface
    public void rent(Customer customer, int days) {
        this.isAvailable = false; // Mark the vehicle as unavailable
        System.out.println("Vehicle rented to " + customer.getName() + " for " + days + " days.");
    }

    // Return method from Rentable interface
    public void returnVehicle() {
        this.isAvailable = true; // Mark the vehicle as available
        System.out.println("Vehicle returned and is now available for rent.");
    }

    @Override
    public String toString() {
        return model + " (" + vehicleId + ")";
    }
}
