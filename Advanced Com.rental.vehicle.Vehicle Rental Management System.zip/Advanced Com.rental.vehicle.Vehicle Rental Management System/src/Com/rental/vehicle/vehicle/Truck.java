package Com.rental.vehicle.vehicle;

public class Truck extends Vehicle {

    public Truck(String vehicleId, String model, double baseRentalRate) {
        super(vehicleId, model, baseRentalRate);
    }

    @Override
    public double calculateRentalCost(int days) {
        return getBaseRentalRate() * days * 1.5; // Trucks have a higher rental rate
    }
}
