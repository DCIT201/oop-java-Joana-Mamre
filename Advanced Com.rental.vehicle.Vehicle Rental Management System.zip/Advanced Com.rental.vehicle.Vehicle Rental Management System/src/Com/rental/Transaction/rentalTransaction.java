package Com.rental.Transaction;

import Com.rental.customer.Customer;
import Com.rental.vehicle.vehicle.Vehicle;

public class rentalTransaction {
    private Customer customer;
    private Vehicle vehicle;
    private int days;
    private boolean isCompleted;

    public rentalTransaction(Customer customer, Vehicle vehicle, int days) {
        this.customer = customer;
        this.vehicle = vehicle;
        this.days = days;
        this.isCompleted = false;
    }

    public void processTransaction() {
        if (vehicle.isAvailableForRental()) {
            vehicle.rent(customer, days);
            double rentalCost = vehicle.calculateRentalCost(days);
            System.out.println("Rental Cost: " + rentalCost);
            isCompleted = true;
        } else {
            System.out.println("The vehicle is not available for rental.");
        }
    }

    public void returnVehicle() {
        if (isCompleted) {
            vehicle.returnVehicle();
            isCompleted = false;
        } else {
            System.out.println("The transaction is not completed yet.");
        }
    }
}
